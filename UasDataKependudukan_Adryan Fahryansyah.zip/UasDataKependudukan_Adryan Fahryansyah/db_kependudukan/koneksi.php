<?php
 define ('host','localhost');
 define ('user','root');
 define ('pass','');
 define ('db','db_kependudukan');

 $konek = mysqli_connect(host,user,pass,db) or die("Data mysqli tidak terhubung");
