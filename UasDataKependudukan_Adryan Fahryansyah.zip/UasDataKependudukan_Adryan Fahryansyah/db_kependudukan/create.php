<?php
require("koneksi.php");

$response = array();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $nama = $_POST["nama"];
    $nik = $_POST["nik"];
    $jenis_kelamin = $_POST["jenis_kelamin"];
    $pekerjaan = $_POST["pekerjaan"];
    $alamat = $_POST["alamat"];

    $perintah = "INSERT INTO tbl_kependudukan (nama, nik, jenis_kelamin, pekerjaan, alamat) VALUES ('$nama','$nik','$jenis_kelamin','$pekerjaan','$alamat')";
    $eksekusi = mysqli_query($konek, $perintah);
    $cek      = mysqli_affected_rows($konek);

    if($cek > 0){
        $response["kode"] = 1;
        $response["pesan"] = "Data Berhasil Disimpan";
    } else{
        $response["kode"] = 0;
        $response["pesan"] = "Gagal Menyimpan Data";
    }

} else {
    $response["kode"] = 0;
    $response["pesan"] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($konek);