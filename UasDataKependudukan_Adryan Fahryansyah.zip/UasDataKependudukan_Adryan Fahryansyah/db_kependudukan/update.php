<?php
require("koneksi.php");

$response = array();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $id = $_POST["id"];
    $nama = $_POST["nama"];
    $nik = $_POST["nik"];
    $jenis_kelamin = $_POST["jenis_kelamin"];
    $pekerjaan = $_POST["pekerjaan"];
    $alamat = $_POST["alamat"];


    $perintah = "UPDATE tbl_kependudukan SET nama = '$nama', nik = '$nik' , jenis_kelamin = '$jenis_kelamin' , pekerjaan = '$pekerjaan' , alamat = '$alamat' where id = '$id'";
    $eksekusi = mysqli_query($konek, $perintah);
    $cek      = mysqli_affected_rows($konek);


    if($cek > 0){
        $response["kode"] = 1;
        $response["pesan"] = "Data Berhasil Diubah";


    } else{
        $response["kode"] = 0;
        $response["pesan"] = "Data Gagal Diubah";
    }

} else {
    $response["kode"] = 0;
    $response["pesan"] = "Tidak Ada Post Data";
}

echo json_encode($response);
mysqli_close($konek);